import { Room } from '@colyseus/core';

const HERO_NAMES = ['Azlan','Rosnah','Imah','Fauzi','Asan','Siti','Umie','Dayah','Saleh','Zul','Yanti','Akmal','Syahmi','Wan'];

export class CutieRoom extends Room {
  maxClients = 8;
  players = new Map();
  winner = null;

  onCreate() {
    this.onMessage('move', (client, data) => {
      const p = this.players.get(client.sessionId);
      if(!p || this.winner) return;
      const x = Math.max(-1, Math.min(1, Number(data?.x)||0));
      const z = Math.max(-1, Math.min(1, Number(data?.z)||0));
      p.x = Math.max(-6, Math.min(6, p.x + x * 0.28));
      p.z = Math.max(-6, Math.min(6, p.z + z * 0.28));
      this.broadcastState();
    });
    this.onMessage('attack', (client) => {
      const p = this.players.get(client.sessionId);
      if(!p || this.winner) return;
      const enemies = [...this.players.entries()].filter(([id,other]) => id !== client.sessionId && other.team !== p.team && other.hp > 0);
      if(!enemies.length) return;
      const target = enemies.sort((a,b) => distance(p,a[1])-distance(p,b[1]))[0];
      if(distance(p,target[1]) <= 3.5) {
        target[1].hp = Math.max(0,target[1].hp - 20);
        const alive = [...this.players.values()].filter(other => other.team === target[1].team && other.hp > 0);
        if(!alive.length) this.winner = p.team === 0 ? 'PINK' : 'BLUE';
        this.broadcastState();
      }
    });
  }

  onJoin(client, options) {
    const teamCounts = [0,0];
    for(const p of this.players.values()) teamCounts[p.team]++;
    const team = teamCounts[0] <= teamCounts[1] ? 0 : 1;
    const hero = HERO_NAMES.includes(options?.hero) ? options.hero : 'Azlan';
    this.players.set(client.sessionId, {
      id: client.sessionId,
      name: String(options?.name || 'Player').slice(0,18),
      hero, team, x: team===0 ? -3 : 3, z: Math.max(-3,Math.min(3,(teamCounts[team]-1.5)*1.2)), hp:100
    });
    this.broadcastState();
  }

  onLeave(client) {
    this.players.delete(client.sessionId);
    this.broadcastState();
  }

  broadcastState() {
    this.broadcast('state', { players:[...this.players.values()], winner:this.winner });
  }
}
function distance(a,b) { return Math.hypot((a.x||0)-(b.x||0),(a.z||0)-(b.z||0)); }

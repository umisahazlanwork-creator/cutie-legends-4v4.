import { Server } from 'colyseus';
import { WebSocketTransport } from '@colyseus/ws-transport';
import { createServer } from 'http';
import { CutieRoom } from './room.js';

const port = Number(process.env.PORT || 2567);
const httpServer = createServer((req,res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if(req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if(req.url === '/' || req.url === '/health') {
    res.writeHead(200, {'Content-Type':'application/json'});
    return res.end(JSON.stringify({ok:true, game:'CUTIE LEGENDS: Geng 4v4'}));
  }
  res.writeHead(404); res.end('Not found');
});
const gameServer = new Server({ transport: new WebSocketTransport({ server: httpServer }) });
gameServer.define('cutie_room', CutieRoom).filterBy([]);
httpServer.listen(port, () => console.log(`CUTIE LEGENDS server listening on ${port}`));

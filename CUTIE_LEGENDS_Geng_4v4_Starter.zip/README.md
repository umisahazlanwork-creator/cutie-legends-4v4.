# CUTIE LEGENDS: Geng 4v4

Starter project for a cute 3D browser MOBA prototype with a real-time Colyseus multiplayer server.

## What's included
- `client/`: Vite + React + React Three Fiber browser game
- `server/`: Colyseus room server with room codes, team assignment, movement sync, and simple attacks
- 14 custom hero names and original ability concepts

## Important hosting note
Vercel hosts the browser client. The Colyseus multiplayer server must run on a separate Node.js host that supports persistent WebSocket connections (for example, a suitable Render/Fly.io deployment). Vercel alone is not the multiplayer server.

## Run locally (best done on a computer)
1. Install Node.js 20 or newer.
2. In one terminal:
   ```bash
   cd server
   npm install
   npm run dev
   ```
3. In a second terminal:
   ```bash
   cd client
   npm install
   cp .env.example .env
   npm run dev
   ```
4. Open the local Vite URL shown in the terminal.

## Android-only path
You can still manage files and GitHub from your phone, but running/building this multi-folder project entirely on Android is harder. First create a GitHub repository, then upload the extracted project files while preserving the `client/` and `server/` folders. A cloud development environment such as GitHub Codespaces (if enabled for your account) is the easiest way to install dependencies and test from Android.

## Deploy
- Deploy `server/` to a Node.js host that supports WebSockets. Set its start command to `npm start`, root directory `server`.
- Deploy `client/` to Vercel. Set project root to `client`, build command `npm run build`, output directory `dist`.
- Set `VITE_GAME_SERVER_URL` in Vercel to the public server URL, e.g. `wss://YOUR-SERVER-URL` (use the URL format expected by Colyseus; normally the server URL is `https://YOUR-SERVER-URL`, and the SDK handles WebSocket transport).
- Redeploy the Vercel client after setting the environment variable.

## Current prototype limits
This is an early multiplayer foundation: room creation/join, 8-player cap, basic movement, simple attack messages, HP and victory condition. It is not yet a complete production-ready MOBA. More gameplay, reconnection handling, server-side validation, anti-cheat, touch controls, and performance testing should be added before public release.

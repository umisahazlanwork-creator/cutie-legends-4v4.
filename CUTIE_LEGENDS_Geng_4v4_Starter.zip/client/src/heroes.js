export const HEROES = [
  {name:'Azlan', role:'Fighter', power:'Shadow Realm', color:'#9b7bff', emoji:'🌑', skill:'Bayang Tebasan'},
  {name:'Rosnah', role:'Mage', power:'Spirit Summoner', color:'#ff8fc7', emoji:'👻', skill:'Roh Penjaga'},
  {name:'Imah', role:'Support', power:'Healing Bloom', color:'#7ee7bc', emoji:'🌷', skill:'Kelopak Pulih'},
  {name:'Fauzi', role:'Tank', power:'Iron Fist', color:'#ffc56e', emoji:'🥊', skill:'Tumbukan Gergasi'},
  {name:'Asan', role:'Assassin', power:'Blink Strike', color:'#80c7ff', emoji:'⚡', skill:'Dash Senyap'},
  {name:'Siti', role:'Mage', power:'Crystal Magic', color:'#ff9f9f', emoji:'💎', skill:'Letupan Kristal'},
  {name:'Umie', role:'Healer', power:'Guardian Aura', color:'#ffd5f0', emoji:'💗', skill:'Aura Kasih'},
  {name:'Dayah', role:'Marksman', power:'Star Arrows', color:'#ffe58a', emoji:'🏹', skill:'Panah Bintang'},
  {name:'Saleh', role:'Fighter', power:'Flame Blade', color:'#ff996b', emoji:'🔥', skill:'Pedang Bara'},
  {name:'Zul', role:'Tank', power:'Steel Dome', color:'#a8b7c9', emoji:'🛡️', skill:'Kubah Besi'},
  {name:'Yanti', role:'Mage', power:'Frost Trap', color:'#9be8ff', emoji:'❄️', skill:'Perangkap Ais'},
  {name:'Akmal', role:'Assassin', power:'Shadow Dash', color:'#b8a1ff', emoji:'🌪️', skill:'Serangan Kritikal'},
  {name:'Syahmi', role:'Fighter', power:'Thunder Rush', color:'#ffe46b', emoji:'⚡', skill:'Petir Berantai'},
  {name:'Wan', role:'Marksman', power:'Energy Cannon', color:'#91f0e6', emoji:'🚀', skill:'Meriam Tenaga'}
];

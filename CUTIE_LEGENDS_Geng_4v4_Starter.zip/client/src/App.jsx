import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { ContactShadows, Float, Html, RoundedBox, Sparkles } from '@react-three/drei';
import { Client } from 'colyseus.js';
import { HEROES } from './heroes.js';

const SERVER_URL = import.meta.env.VITE_GAME_SERVER_URL || 'http://localhost:2567';

function HeroModel({ hero, position=[0,0,0], friendly=true, selected=false }) {
  const ref = useRef();
  useFrame((state, delta) => { if(ref.current) { ref.current.rotation.y += delta * 0.35; ref.current.position.y = 0.65 + Math.sin(state.clock.elapsedTime*2 + position[0])*0.07; } });
  return <group position={position}>
    <Float speed={1.5} rotationIntensity={0.08} floatIntensity={0.12}>
      <mesh ref={ref} castShadow>
        <capsuleGeometry args={[0.34,0.48,6,12]} />
        <meshStandardMaterial color={hero.color} roughness={0.38} />
      </mesh>
      <mesh position={[0,0.45,0.27]} castShadow>
        <sphereGeometry args={[0.28,20,20]} />
        <meshStandardMaterial color="#ffe0c8" roughness={0.6}/>
      </mesh>
      <mesh position={[-0.09,0.48,0.51]}><sphereGeometry args={[0.035,10,10]}/><meshBasicMaterial color="#33264f"/></mesh>
      <mesh position={[0.09,0.48,0.51]}><sphereGeometry args={[0.035,10,10]}/><meshBasicMaterial color="#33264f"/></mesh>
      <mesh position={[0,0.17,0]}><sphereGeometry args={[0.39,20,12]}/><meshStandardMaterial color={friendly?'#7be7c4':'#ff719b'} transparent opacity={0.15}/></mesh>
    </Float>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,0.02,0]}><circleGeometry args={[selected?0.65:0.48,32]}/><meshBasicMaterial color={friendly?'#5fe3bb':'#ff6e96'} transparent opacity={selected?0.7:0.35}/></mesh>
    <Html position={[0,1.45,0]} center distanceFactor={10} style={{pointerEvents:'none'}}>
      <div className="world-label">{hero.name}</div>
    </Html>
  </group>;
}

function Arena({ hero, players, roomState, onMove, onAttack }) {
  const playerModels = useMemo(() => {
    const list = players?.length ? players : [
      {id:'demo1', hero:'Azlan', x:-2, z:1, team:0, hp:100},
      {id:'demo2', hero:'Imah', x:-3, z:2, team:0, hp:100},
      {id:'demo3', hero:'Rosnah', x:2, z:-1, team:1, hp:100},
      {id:'demo4', hero:'Zul', x:3, z:-2, team:1, hp:100}
    ];
    return list.map((p,i)=>({ ...p, hero: HEROES.find(h=>h.name===p.hero)||HEROES[i%HEROES.length] }));
  }, [players]);
  return <Canvas shadows camera={{position:[0,8,10], fov:43}} dpr={[1,1.5]}>
    <color attach="background" args={['#211b42']}/>
    <ambientLight intensity={1.25}/>
    <directionalLight position={[4,9,5]} intensity={2.1} castShadow shadow-mapSize-width={1024} shadow-mapSize-height={1024}/>
    <Sparkles count={55} scale={12} size={2} speed={0.25} color="#d9c9ff"/>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-0.12,0]} receiveShadow>
      <planeGeometry args={[15,15]}/><meshStandardMaterial color="#b6e6cb" roughness={1}/>
    </mesh>
    <gridHelper args={[14,14,'#a1d4be','#c8efdb']} position={[0,-0.1,0]}/>
    <RoundedBox args={[2.2,0.3,1.2]} radius={0.25} position={[-5,0.12,0]} castShadow><meshStandardMaterial color="#ff8db6"/></RoundedBox>
    <RoundedBox args={[2.2,0.3,1.2]} radius={0.25} position={[5,0.12,0]} castShadow><meshStandardMaterial color="#8fa8ff"/></RoundedBox>
    {playerModels.map((p,i)=><HeroModel key={p.id||i} hero={p.hero} position={[p.x ?? ((i%4)-1.5)*1.3,0,p.z ?? ((i<4)?2:-2)]} friendly={p.team===0} selected={p.id===roomState?.sessionId}/>)}
    <ContactShadows position={[0,-0.08,0]} opacity={0.25} scale={14} blur={2}/>
  </Canvas>;
}

export default function App() {
  const [selected, setSelected] = useState(HEROES[0]);
  const [playerName, setPlayerName] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [room, setRoom] = useState(null);
  const [players, setPlayers] = useState([]);
  const [status, setStatus] = useState('Pilih hero dan cipta bilik untuk mula.');
  const [busy, setBusy] = useState(false);
  const [move, setMove] = useState({x:0,z:0});
  const client = useMemo(() => new Client(SERVER_URL), []);
  const roomRef = useRef(null);

  useEffect(() => {
    const r = roomRef.current;
    return () => { if(r) r.leave(); };
  }, []);

  const bindRoom = (joined) => {
    roomRef.current = joined;
    setRoom(joined);
    setRoomCode(joined.roomId);
    setStatus('Berjaya masuk bilik! Kongsi kod ini dengan kawan.');
    joined.onMessage('state', (snapshot) => {
      setPlayers(snapshot.players || []);
      if(snapshot.winner) setStatus('Pasukan '+snapshot.winner+' menang!');
    });
    joined.onLeave(()=>{setRoom(null); setPlayers([]); setStatus('Terputus daripada bilik.');});
    joined.onError((code,message)=>setStatus('Ralat bilik: '+message));
  };

  const createRoom = async () => {
    if(!playerName.trim()) { setStatus('Masukkan nama pemain dahulu.'); return; }
    setBusy(true);
    try { const r=await client.create('cutie_room',{name:playerName.trim(),hero:selected.name}); bindRoom(r); }
    catch(e){setStatus('Tak dapat sambung ke server. Pastikan server multiplayer sudah online.');}
    finally{setBusy(false);}
  };
  const joinRoom = async () => {
    if(!playerName.trim() || !roomCode.trim()) { setStatus('Masukkan nama dan kod bilik.'); return; }
    setBusy(true);
    try { const r=await client.joinById(roomCode.trim(),{name:playerName.trim(),hero:selected.name}); bindRoom(r); }
    catch(e){setStatus('Tak berjaya masuk. Semak kod bilik atau pastikan server sudah online.');}
    finally{setBusy(false);}
  };
  const sendMove = (x,z) => { setMove({x,z}); room?.send('move',{x,z}); };
  const attack = () => { if(room) room.send('attack',{targetTeam: room.state?.players?.get(room.sessionId)?.team===0?1:0}); else setStatus('Cipta atau masuk bilik dahulu untuk menyerang.'); };

  return <main className="app-shell">
    <header className="topbar"><div className="logo-mark">✦</div><div><div className="eyebrow">CUTE 3D MULTIPLAYER ARENA</div><h1>CUTIE <span>LEGENDS</span></h1></div><div className="players-pill">⚔️ 4v4</div></header>
    <section className="hero-banner"><div><div className="tag">GENG KITA, LEGEND KITA</div><h2>Jom masuk arena!</h2><p>Pilih hero, kumpul geng dan bertarung bersama.</p></div><div className="banner-star">✦</div></section>
    <section className="arena-card"><div className="section-heading"><div><span className="live-dot"></span> ARENA PREVIEW</div><span className="tiny-pill">{room ? 'ROOM '+room.roomId : 'DEMO MODE'}</span></div><div className="arena-view"><Arena hero={selected} players={players} roomState={room}/></div><div className="arena-footer"><span>🌸 Crystal Meadow</span><span>{players.length || 4}/8 hero dipaparkan</span></div></section>
    <section className="panel">
      <div className="section-title"><div><span className="step-no">01</span><h3>Siapa nama awak?</h3></div></div>
      <input className="text-input" value={playerName} onChange={e=>setPlayerName(e.target.value)} placeholder="Contoh: AmieLyzz" maxLength={18}/>
      <div className="section-title hero-title"><div><span className="step-no">02</span><h3>Pilih hero</h3></div><span className="muted">{selected.role}</span></div>
      <div className="hero-grid">{HEROES.map(h=><button key={h.name} onClick={()=>setSelected(h)} className={'hero-tile '+(selected.name===h.name?'chosen':'')} style={{'--hero':h.color}}><span className="hero-orb">{h.emoji}</span><strong>{h.name}</strong><small>{h.role}</small></button>)}</div>
      <div className="ability-card" style={{'--hero':selected.color}}><div className="ability-icon">{selected.emoji}</div><div><small>KUASA KHAS</small><strong>{selected.power}</strong><span>{selected.skill}</span></div><span className="ability-spark">✧</span></div>
    </section>
    <section className="panel room-panel">
      <div className="section-title"><div><span className="step-no">03</span><h3>Bilik permainan</h3></div></div>
      <button className="primary-btn" disabled={busy||!!room} onClick={createRoom}>{busy?'Sedang sambung...':room?'Sudah dalam bilik':'✦ Cipta bilik baru'}</button>
      <div className="or-line"><span>ATAU MASUK BILIK KAWAN</span></div>
      <div className="join-row"><input className="text-input code-input" value={roomCode} onChange={e=>setRoomCode(e.target.value.toUpperCase())} placeholder="Kod bilik"/><button className="join-btn" disabled={busy||!!room} onClick={joinRoom}>Masuk</button></div>
      {room&&<div className="room-share"><span>KOD BILIK</span><strong>{room.roomId}</strong><button onClick={()=>navigator.clipboard?.writeText(room.roomId)}>Salin kod</button><button onClick={()=>room.leave()}>Keluar bilik</button></div>}
      <p className="status-message">{status}</p>
      <div className="player-list"><strong>Pemain dalam bilik ({players.length}/8)</strong>{players.map((p,i)=><div className="player-row" key={p.id}><span className="player-dot" style={{background:p.team===0?'#ff8eb8':'#8ea7ff'}}></span><span>{p.name} <small>· {p.hero}</small></span><span className="team-label">{p.team===0?'PINK':'BLUE'}</span></div>)}</div>
    </section>
    <section className="panel controls-panel"><div className="section-title"><div><span className="step-no">04</span><h3>Kawalan mudah</h3></div></div><div className="control-layout"><div className="dpad"><button onTouchStart={e=>{e.preventDefault();sendMove(0,-1)}} onClick={()=>sendMove(0,-1)}>▲</button><div><button onTouchStart={e=>{e.preventDefault();sendMove(-1,0)}} onClick={()=>sendMove(-1,0)}>◀</button><span>MOVE</span><button onTouchStart={e=>{e.preventDefault();sendMove(1,0)}} onClick={()=>sendMove(1,0)}>▶</button></div><button onTouchStart={e=>{e.preventDefault();sendMove(0,1)}} onClick={()=>sendMove(0,1)}>▼</button></div><div className="skill-buttons"><button onClick={attack}><span>✦</span><small>SKILL</small></button><button onClick={attack}><span>💥</span><small>ULTI</small></button></div></div><p className="muted small">Prototaip: kawalan dan serangan asas sedang dibangunkan. Gunakan bilik multiplayer apabila pelayan telah diterbitkan.</p></section>
    <footer>Made with ♡ for the geng · CUTIE LEGENDS v0.1</footer>
  </main>;
}
